Updated branded website package for VLSL + Lido Chem.
