"use client";

import { ArrowRight, Mail, Phone, MapPin } from "lucide-react";

const colors = {
  dark: "#4F5D43",
  mid: "#7D8F6B",
  light: "#D8D2C3",
  text: "#1f2937",
};

export default function Page() {
  return (
    <main style={{ fontFamily: "Inter, sans-serif", background: colors.light, color: colors.text }}>
      <header className="topbar" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 40px", background: "white", borderBottom: "1px solid #e5e7eb" }}>
        <div style={{ display: "flex", gap: 18, alignItems: "center" }}>
          <img src="/logos/vlsl.png" alt="VLSL Logo" style={{ height: 38 }} />
          <img src="/logos/lido.png" alt="Lido Chem Logo" style={{ height: 38 }} />
        </div>
        <div className="navlinks" style={{ display: "flex", gap: 28, fontSize: 14, color: "#374151" }}>
          <a href="#about">About</a>
          <a href="#products">Products</a>
          <a href="#team">Leadership</a>
          <a href="#contact">Contact</a>
        </div>
      </header>

      <section className="hero" style={{ padding: "110px 40px", textAlign: "center", background: `linear-gradient(135deg, ${colors.dark}, ${colors.mid})`, color: "white" }}>
        <h1 style={{ fontSize: 44, fontWeight: 700, maxWidth: 900, margin: "0 auto", letterSpacing: "-0.03em" }}>
          Chemistry. Trust. Innovation.
        </h1>
        <p style={{ marginTop: 16, opacity: 0.92, fontSize: 18 }}>
          Vipul Life Science Limited & Lido Chem LLP
        </p>
        <div style={{ marginTop: 28 }}>
          <a href="#contact" style={{ background: "white", color: colors.dark, padding: "12px 22px", borderRadius: 10, fontWeight: 600, display:"inline-flex", alignItems:"center", gap:8 }}>
            Send Inquiry <ArrowRight size={14} />
          </a>
        </div>
      </section>

      <section id="about" style={{ padding: "70px 40px", textAlign: "center" }}>
        <h2 style={{ fontSize: 28, fontWeight: 700 }}>About</h2>
        <p style={{ marginTop: 14, maxWidth: 650, marginInline: "auto", color: "#475569", lineHeight: 1.8 }}>
          Specialty chemical sourcing, development, and supply through strong industry partnerships.
        </p>
      </section>

      <section id="products" style={{ padding: "70px 40px", background: "white" }}>
        <h2 style={{ textAlign: "center", fontSize: 28, fontWeight: 700 }}>Products & Services</h2>
        <div className="product-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 18, marginTop: 40 }}>
          {["Specialty Sourcing","Imports","R&D","Manufacturing","Intermediates"].map((item) => (
            <div key={item} style={{ background: colors.light, padding: 20, borderRadius: 12, border: "1px solid #e5e7eb" }}>
              <div style={{ fontWeight: 600 }}>{item}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="team" style={{ padding: "70px 40px" }}>
        <h2 style={{ textAlign: "center", fontSize: 28, fontWeight: 700 }}>Leadership</h2>
        <div className="team-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 18, marginTop: 40 }}>
          {[
            ["Sunil Sheth","Director – VLSL"],
            ["Vipul Sheth","Director – VLSL"],
            ["Parshwa Sheth","Partner – Lido Chem LLP"],
            ["Dewal Sheth","Partner – Lido Chem LLP"],
          ].map(([name, role]) => (
            <div key={name} style={{ background: "white", padding: 20, borderRadius: 12, border: "1px solid #e5e7eb" }}>
              <div style={{ fontWeight: 700 }}>{name}</div>
              <div style={{ color: "#64748b", fontSize: 13, marginTop: 4 }}>{role}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" style={{ padding: "70px 40px", background: colors.dark, color: "white", textAlign: "center" }}>
        <h2 style={{ fontSize: 28, fontWeight: 700 }}>Contact</h2>
        <div style={{ marginTop: 20, display: "grid", gap: 8, justifyContent: "center" }}>
          <div style={{ display:"flex", gap:8, alignItems:"center", justifyContent:"center" }}><Mail size={14} /> business@yourcompany.com</div>
          <div style={{ display:"flex", gap:8, alignItems:"center", justifyContent:"center" }}><Phone size={14} /> +91 XXXXX XXXXX</div>
          <div style={{ display:"flex", gap:8, alignItems:"center", justifyContent:"center" }}><MapPin size={14} /> India</div>
        </div>
      </section>
    </main>
  );
}