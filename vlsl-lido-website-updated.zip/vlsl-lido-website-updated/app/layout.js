export const metadata = {
  title: "Vipul Life Science Limited | Lido Chem LLP",
  description: "Specialty Chemical Solutions with Reliable Supply & Global Reach.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}