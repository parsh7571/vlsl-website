export const metadata = {
  title: "Vipul Life Science Limited | Lido Chem LLP",
  description: "Specialty chemicals, solvents, intermediates, customer-led development, and third-party manufacturing.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}