export const metadata = {
  title: "Vipul Life Science Limited | Lido Chem LLP",
  description: "Premium corporate website for Vipul Life Science Limited and its group company Lido Chem LLP.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}