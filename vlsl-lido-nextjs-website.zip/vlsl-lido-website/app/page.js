"use client";

import { motion } from "framer-motion";
import { ArrowRight, Beaker, Factory, Globe2, ShieldCheck, Mail, MapPin, Phone, Download, ChevronRight, FlaskConical, Search } from "lucide-react";
import { useMemo, useState } from "react";

const products = [
  { name: "Specialty Chemical Sourcing", category: "Trading & Distribution", desc: "Sourcing support for pharmaceutical, specialty, and industrial chemical requirements through an agile and reliable commercial network." },
  { name: "R&D-Based Product Development", category: "Innovation", desc: "Customer-driven development support for new products and application-specific requirements." },
  { name: "Custom Supply Solutions", category: "Commercial", desc: "Flexible sourcing, development, and partner manufacturing support for evolving market requirements." },
  { name: "Imported Speciality Chemicals", category: "Lido Chem LLP", desc: "Import and distribution support through Lido Chem LLP for speciality chemicals and customer-specific sourcing requirements." },
];

const capabilities = [
  { title: "R&D-Driven Development", icon: <Beaker size={22} />, text: "Product development support based on customer requirements, performance targets, and commercial feasibility." },
  { title: "Reliable Manufacturing Ecosystem", icon: <Factory size={22} />, text: "Efficient execution through dependable third-party manufacturing relationships for scalable production support." },
  { title: "Global Sourcing & Imports", icon: <Globe2 size={22} />, text: "Import, sourcing, and distribution capability through Lido Chem LLP for speciality chemicals." },
];

const strengths = [
  "Specialty chemical business focus",
  "Customer-led product development approach",
  "Flexible commercial execution",
  "Import and distribution capability",
  "Dependable partner manufacturing model",
  "Professional global business presentation",
];

export default function Page() {
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) =>
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.desc.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <main>
      <header className="nav">
        <div className="container nav-inner">
          <div className="logo-row">
            <div className="logo-card"><img src="/logos/vlsl.png" alt="Vipul Life Science Limited logo" style={{ height: 48 }} /></div>
            <div className="logo-card"><img src="/logos/lido.png" alt="Lido Chem LLP logo" style={{ height: 48 }} /></div>
          </div>
          <nav className="nav-links">
            <a href="#about">About</a>
            <a href="#capabilities">Capabilities</a>
            <a href="#products">Portfolio</a>
            <a href="#contact">Contact</a>
          </nav>
        </div>
      </header>

      <section className="hero">
        <div className="container hero-grid">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .55 }}>
            <div className="badge"><ShieldCheck size={16} /> Specialty Chemicals • R&D Support • Global Sourcing</div>
            <h1>Premium digital presence for Vipul Life Science Limited and Lido Chem LLP.</h1>
            <p>A refined, client-facing corporate website built to showcase technical credibility, sourcing capability, and strong business presentation for your group.</p>
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginTop: 28 }}>
              <a className="btn btn-primary" href="#contact">Send Inquiry <ArrowRight size={16} /></a>
              <a className="btn btn-secondary" href="#products">View Portfolio</a>
            </div>
            <div className="stat-grid">
              {[["R&D","Support"],["Import","Capability"],["Supply","Reliability"],["Client","Focused"]].map(([a,b]) => (
                <div className="stat-card" key={a}>
                  <div className="stat-title">{a}</div>
                  <div className="stat-sub">{b}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .65, delay: .08 }}>
            <div style={{ display: "grid", gap: 18 }}>
              <div className="card">
                <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 18 }}>
                  <div className="icon-badge"><FlaskConical size={22} /></div>
                  <div>
                    <div className="kicker" style={{ letterSpacing: ".18em" }}>Group Overview</div>
                    <div style={{ fontSize: 22, fontWeight: 700 }}>Business-led, technical, export-facing</div>
                  </div>
                </div>
                <p className="muted">Vipul Life Science Limited is positioned around specialty chemicals and customer-oriented development support, while Lido Chem LLP adds import and distribution capability.</p>
              </div>

              <div className="dark-card">
                <div className="kicker" style={{ color: "#86efac" }}>Use Cases</div>
                <div style={{ fontSize: 28, fontWeight: 700, lineHeight: 1.2, marginTop: 8 }}>Built for customers, suppliers, trade fairs, and international outreach.</div>
                <p style={{ marginTop: 14, lineHeight: 1.9 }}>This format is suitable for brochures, website launches, client presentations, and modern corporate positioning.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="about" className="section">
        <div className="container" style={{ display: "grid", gridTemplateColumns: "0.9fr 1.1fr", gap: 36 }}>
          <div>
            <div className="kicker">About</div>
            <h2>One group, multiple capabilities, stronger market presence.</h2>
          </div>
          <div className="card" style={{ boxShadow: "0 8px 18px rgba(15,23,42,.05)" }}>
            <p className="muted">Vipul Life Science Limited is positioned as a specialty chemical-focused business with product understanding, customer-led development support, and dependable commercial execution. The group is complemented by Lido Chem LLP, which adds import and distribution strength for speciality chemicals.</p>
          </div>
        </div>
      </section>

      <section id="capabilities" className="section" style={{ background: "white" }}>
        <div className="container">
          <div className="section-header" style={{ textAlign: "center" }}>
            <div className="kicker">Capabilities</div>
            <h2>Core strengths presented like a premium corporate brand.</h2>
          </div>
          <div className="grid-3">
            {capabilities.map((item) => (
              <motion.div whileHover={{ y: -4 }} className="soft-card" key={item.title}>
                <div className="icon-badge">{item.icon}</div>
                <h3 style={{ fontSize: 24, margin: "16px 0 0", fontWeight: 700 }}>{item.title}</h3>
                <p className="muted" style={{ marginTop: 12, fontSize: 14 }}>{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="products" className="section">
        <div className="container">
          <div style={{ display: "flex", justifyContent: "space-between", gap: 20, alignItems: "end", flexWrap: "wrap", marginBottom: 36 }}>
            <div>
              <div className="kicker">Portfolio</div>
              <h2>Product and business capability showcase.</h2>
            </div>
            <div style={{ position: "relative", width: "min(380px,100%)" }}>
              <Search size={16} style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)", color: "#94a3b8" }} />
              <input className="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search product category or capability" style={{ paddingLeft: 40 }} />
            </div>
          </div>

          <div className="grid-2">
            {filtered.map((item) => (
              <div className="card" style={{ boxShadow: "0 8px 18px rgba(15,23,42,.05)" }} key={item.name}>
                <div className="pill">{item.category}</div>
                <h3 style={{ fontSize: 24, margin: "14px 0 0", fontWeight: 700 }}>{item.name}</h3>
                <p className="muted" style={{ marginTop: 12, fontSize: 14 }}>{item.desc}</p>
                <div style={{ marginTop: 18, display: "inline-flex", alignItems: "center", gap: 8, color: "#15803d", fontWeight: 700, fontSize: 14 }}>
                  Learn more <ChevronRight size={16} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" style={{ background: "#eef7f0" }}>
        <div className="container grid-2">
          <div className="highlight-panel">
            <div className="kicker" style={{ color: "#dcfce7" }}>Why Clients Trust This Format</div>
            <h2 style={{ marginTop: 12, color: "white" }}>Corporate, polished, and built for credibility.</h2>
            <p>This website style gives your business the presence of a professionally built specialty chemicals brand.</p>
            <button className="btn" style={{ background: "white", color: "#15803d", marginTop: 16 }}><Download size={16} /> Download Brochure</button>
          </div>

          <div className="grid-2">
            {strengths.map((item) => (
              <div className="card" style={{ padding: 22, boxShadow: "0 8px 18px rgba(15,23,42,.05)" }} key={item}>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <div className="icon-badge" style={{ width: 38, height: 38, borderRadius: 999 }}><ShieldCheck size={16} /></div>
                  <div style={{ fontSize: 14, lineHeight: 1.9, fontWeight: 600, color: "#334155" }}>{item}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="section contact-wrap">
        <div className="container">
          <div className="contact-panel">
            <div className="grid-2" style={{ alignItems: "start" }}>
              <div>
                <div className="kicker" style={{ color: "#86efac" }}>Contact</div>
                <h2 style={{ marginTop: 12, color: "white" }}>Ready to turn this into your live corporate website.</h2>
                <p style={{ marginTop: 16, color: "#cbd5e1", lineHeight: 1.9, maxWidth: 720 }}>This version is structured like a deployable company website and can be extended with inquiry forms, product detail pages, brochure downloads, and real corporate assets.</p>
                <div className="footer-note">Prepared as a deployable Next.js starter for your brand.</div>
              </div>

              <div style={{ display: "grid", gap: 14 }}>
                <div className="contact-chip"><Mail size={16} style={{ color: "#86efac", marginRight: 10, verticalAlign: "middle" }} /> business@yourcompany.com</div>
                <div className="contact-chip"><Phone size={16} style={{ color: "#86efac", marginRight: 10, verticalAlign: "middle" }} /> +91 Company Contact Number</div>
                <div className="contact-chip"><MapPin size={16} style={{ color: "#86efac", marginRight: 10, verticalAlign: "middle" }} /> India</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}