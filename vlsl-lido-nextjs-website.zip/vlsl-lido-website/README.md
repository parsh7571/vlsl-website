# Vipul Life Science Limited + Lido Chem LLP Website

Deployable Next.js website starter.

## Run locally
```bash
npm install
npm run dev
```

## Logos
- VLSL: /logos/vlsl.png
- Lido: /logos/lido.png
