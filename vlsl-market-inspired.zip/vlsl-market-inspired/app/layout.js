export const metadata = {
  title: "Vipul Life Science Limited | Lido Chem LLP",
  description: "Specialty chemicals, pharmaceutical intermediates, sourcing, and distribution.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}