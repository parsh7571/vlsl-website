"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Mail, MapPin, Phone, ShieldCheck, FlaskConical, Target, Eye, Users, Truck, BadgeCheck, Building2 } from "lucide-react";

const neutral = {
  bg: "#F5F2EB",
  card: "#FFFFFF",
  text: "#1F2937",
  muted: "#64748B",
  border: "rgba(31,41,55,0.10)",
  hero1: "#EEE8DC",
  hero2: "#DCD4C3",
  pill: "#FFFFFF",
  accent: "#6B7280",
};

const themes = {
  vlsl: {
    bg: "#F7F9FC",
    card: "#FFFFFF",
    text: "#1F2937",
    muted: "#64748B",
    border: "rgba(31,41,55,0.10)",
    hero1: "#EEF3FB",
    hero2: "#E2E8F6",
    accent: "#F97316",
    deep: "#334155",
    wash: "#FFF7ED",
  },
  lido: {
    bg: "#F8F7F2",
    card: "#FFFFFF",
    text: "#1F2937",
    muted: "#64748B",
    border: "rgba(79,93,67,0.10)",
    hero1: "#EEF0E6",
    hero2: "#D8D2C3",
    accent: "#4F5D43",
    deep: "#4F5D43",
    wash: "#ECE8DB",
  }
};

const companyData = {
  vlsl: {
    name: "Vipul Life Science Limited",
    sub: "Your Global Partner in Pharmaceutical Intermediates",
    logo: "/logos/vlsl-logo.png",
    hero: "A long-standing specialty chemicals business serving the pharmaceutical sector with quality, technical understanding, dependable sourcing, and execution-focused support.",
    about: "Vipul Life Science Limited is positioned around specialty chemicals, solvents, and pharmaceutical intermediates with a customer-led approach to development and supply. The business combines product understanding, sourcing strength, and responsiveness to support long-term customer relationships.",
    stats: ["Since 1990 in pharma", "Roots tracing to 1952", "Customer-led development", "Reliable sourcing network"],
    capabilities: [
      "Pharmaceutical Intermediates",
      "Specialty Chemicals",
      "Solvents & Basic Chemicals",
      "Customer-Led Development",
    ],
    mission: "To deliver dependable chemical solutions through quality, transparency, responsiveness, and customer-focused service.",
    vision: "To strengthen long-term customer relationships by becoming a trusted partner for specialty chemicals and pharmaceutical intermediates.",
    approach: [
      "Integrity and transparency in every interaction",
      "Quality aligned with stringent standards",
      "Customer focus and solution orientation",
      "Reliable sourcing and supply support",
      "On-time delivery with responsive execution",
      "Trusted third-party manufacturing partnerships",
    ],
    industries: ["Pharmaceuticals", "Life Sciences", "Fine Chemicals", "Specialty Chemical Applications"],
    productsIntro: "The profile focuses on industry relevance rather than listing every item, creating a cleaner and more credible pharma-facing presentation.",
    products: ["Pharmaceutical Intermediates","Specialty Chemical Intermediates","Solvents","Basic & Performance Chemicals"],
    leaders: [["Sunil Sheth","Director"],["Vipul Sheth","Director"],["Parshwa Sheth","Next Generation Leadership"],["Dewal Sheth","Next Generation Leadership"]],
    contact: {
      email: "ds@vipullife.com",
      phone: "+91 85917 44209",
      address: "205/206, BPS Plaza, BPS Estate, Devidayal Road, Mulund (W), Mumbai 400080, India",
    },
  },
  lido: {
    name: "Lido Chem LLP",
    sub: "Chemistry. Trust. Innovation.",
    logo: "/logos/lido-logo.png",
    hero: "A modern sourcing and specialty chemicals platform built around trust, transparency, relationship-driven service, and dependable supply execution.",
    about: "Lido Chem LLP is positioned as a customer-focused sourcing and distribution business supporting speciality chemicals, imports, and commercial execution. The presentation is designed to communicate reliability, professionalism, and a clear commitment to long-term partnerships.",
    stats: ["Customer-first approach", "Relationship-led business style", "Transparent commitments", "Dependable supply support"],
    capabilities: [
      "Specialty Chemical Sourcing",
      "Imports & Distribution",
      "Commercial Supply Support",
      "Responsive Customer Service",
    ],
    mission: "To support customers with dependable sourcing, transparent communication, and quality-led execution from inquiry to delivery.",
    vision: "To be a trusted specialty chemicals sourcing partner known for relationships, responsiveness, and on-time supply.",
    approach: [
      "Trust as the basis of long-term partnerships",
      "Transparency in commitments and communication",
      "Quality-first sourcing mindset",
      "On-time delivery and dependable follow-through",
      "Flexible response to customer requirements",
      "Professional execution from inquiry to supply",
    ],
    industries: ["Pharmaceuticals", "Specialty Chemicals", "Trading & Distribution", "Customer-Driven Sourcing Requirements"],
    productsIntro: "The page is intentionally customer-facing and market-appropriate, with clear positioning around sourcing, distribution, and service rather than an overloaded catalog.",
    products: ["Imported Specialty Chemicals","Sourcing Solutions","Commercial Supply Support","Distribution-Oriented Execution"],
    leaders: [["Parshwa Sheth","Partner"],["Dewal Sheth","Partner"]],
    contact: {
      email: "business@yourcompany.com",
      phone: "+91 XXXXX XXXXX",
      address: "India",
    },
  }
};

function Header({ onHome, theme }) {
  return (
    <header style={{position:"sticky",top:0,zIndex:50,background:"rgba(255,255,255,0.76)",backdropFilter:"blur(14px)",borderBottom:`1px solid ${theme.border}`}}>
      <div className="page-wrap header-wrap" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",padding:"18px 0",display:"flex",alignItems:"center",justifyContent:"space-between",gap:20}}>
        <button onClick={onHome} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:999,padding:"10px 16px",fontWeight:700,color:theme.deep,cursor:"pointer",boxShadow:"0 10px 24px rgba(31,41,55,0.06)"}}>
          ← Home
        </button>
        <nav style={{display:"flex",gap:22,fontWeight:700,color:theme.deep,flexWrap:"wrap"}}>
          <a href="#about">About</a>
          <a href="#vision">Vision</a>
          <a href="#capabilities">Capabilities</a>
          <a href="#industries">Industries</a>
          <a href="#contact">Contact</a>
        </nav>
      </div>
    </header>
  );
}

function SectionTitle({ eyebrow, title, color }) {
  return (
    <div style={{textAlign:"center",maxWidth:820,margin:"0 auto"}}>
      <div style={{fontSize:12,fontWeight:800,letterSpacing:".2em",textTransform:"uppercase",color}}>{eyebrow}</div>
      <h2 style={{fontSize:"clamp(30px,4vw,48px)",lineHeight:1.05,letterSpacing:"-0.04em",marginTop:12,marginBottom:0}}>
        {title}
      </h2>
    </div>
  );
}

function CompanyView({ company, onHome }) {
  const data = companyData[company];
  const theme = themes[company];
  return (
    <main style={{ background: theme.bg, color: theme.text }}>
      <Header onHome={onHome} theme={theme} />

      <section className="hero-grid" style={{background:`linear-gradient(135deg, ${theme.hero1} 0%, ${theme.hero2} 100%)`,position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at top left, rgba(255,255,255,.42), transparent 26%), radial-gradient(circle at right, rgba(255,255,255,.2), transparent 30%)"}} />
        <div className="page-wrap hero-grid" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",minHeight:680,display:"grid",gridTemplateColumns:"1.08fr 0.92fr",gap:30,alignItems:"center",padding:"70px 0",position:"relative"}}>
          <div>
            <div style={{display:"inline-flex",alignItems:"center",gap:10,background:"#fff",border:`1px solid ${theme.border}`,color:theme.deep,borderRadius:999,padding:"10px 16px",fontSize:14,fontWeight:700,boxShadow:"0 8px 20px rgba(31,41,55,0.05)"}}>
              {data.sub}
            </div>
            <h1 style={{color:theme.text,fontSize:"clamp(42px, 6vw, 78px)",lineHeight:0.96,letterSpacing:"-0.05em",margin:"22px 0 0",maxWidth:760}}>
              {data.name}
            </h1>
            <p style={{color:theme.muted,fontSize:18,lineHeight:1.9,maxWidth:720,marginTop:24}}>
              {data.hero}
            </p>
          </div>
          <motion.div whileHover={{y:-4}} style={{background:"#fff",borderRadius:34,padding:24,boxShadow:"0 28px 80px rgba(31,41,55,0.12)",display:"flex",alignItems:"center",justifyContent:"center",minHeight:360,border:`1px solid ${theme.border}`}}>
            <img src={data.logo} alt={data.name} style={{maxHeight:290,width:"100%",objectFit:"contain"}} />
          </motion.div>
        </div>
      </section>

      <section style={{padding:"28px 0 88px",background:theme.bg}}>
        <div className="page-wrap stats-grid" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:18}}>
          {data.stats.map((item)=>(
            <div key={item} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:20,padding:"18px 20px",fontWeight:700,boxShadow:"0 10px 24px rgba(31,41,55,0.05)"}}>
              {item}
            </div>
          ))}
        </div>
      </section>

      <section id="about" style={{padding:"0 0 88px",background:theme.bg}}>
        <div className="page-wrap about-grid" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",display:"grid",gridTemplateColumns:"0.92fr 1.08fr",gap:28}}>
          <div>
            <div style={{fontSize:12,fontWeight:800,letterSpacing:".2em",textTransform:"uppercase",color:theme.accent}}>About Company</div>
            <h2 style={{fontSize:"clamp(30px,4vw,48px)",lineHeight:1.05,letterSpacing:"-0.04em",marginTop:12,marginBottom:0}}>
              Built for quality, relationships, and dependable business execution.
            </h2>
          </div>
          <div style={{background:theme.card,border:`1px solid ${theme.border}`,borderRadius:30,padding:32,boxShadow:"0 14px 34px rgba(31,41,55,0.05)"}}>
            <p style={{margin:0,color:theme.muted,lineHeight:1.9}}>{data.about}</p>
          </div>
        </div>
      </section>

      <section id="vision" style={{padding:"88px 0",background:theme.wash}}>
        <div className="page-wrap vision-grid" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
          <motion.div whileHover={{y:-4}} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:30,padding:30,boxShadow:"0 12px 28px rgba(31,41,55,0.05)"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,color:theme.accent,fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",fontSize:12}}>
              <Target size={16}/> Mission
            </div>
            <p style={{margin:"14px 0 0",color:theme.muted,lineHeight:1.9,fontWeight:600}}>{data.mission}</p>
          </motion.div>
          <motion.div whileHover={{y:-4}} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:30,padding:30,boxShadow:"0 12px 28px rgba(31,41,55,0.05)"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,color:theme.accent,fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",fontSize:12}}>
              <Eye size={16}/> Vision
            </div>
            <p style={{margin:"14px 0 0",color:theme.muted,lineHeight:1.9,fontWeight:600}}>{data.vision}</p>
          </motion.div>
        </div>
      </section>

      <section id="capabilities" style={{padding:"88px 0",background:theme.bg}}>
        <div className="page-wrap" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto"}}>
          <SectionTitle eyebrow="Capabilities" title="Focused capabilities presented with clarity and confidence." color={theme.accent} />
          <div className="caps-grid" style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:18,marginTop:36}}>
            {data.capabilities.map((item)=>(
              <motion.div key={item} whileHover={{y:-4}} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:24,padding:24,boxShadow:"0 12px 28px rgba(31,41,55,0.05)",fontWeight:700}}>
                {item}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="approach" style={{padding:"88px 0",background:theme.wash}}>
        <div className="page-wrap" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto"}}>
          <SectionTitle eyebrow="Why Work With Us" title="The business principles that shape every customer relationship." color={theme.accent} />
          <div className="approach-grid" style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:18,marginTop:36}}>
            {data.approach.map((item)=>(
              <motion.div key={item} whileHover={{y:-4}} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:24,padding:22,boxShadow:"0 12px 28px rgba(31,41,55,0.05)",color:theme.muted,lineHeight:1.8,fontWeight:600}}>
                {item}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="industries" style={{padding:"88px 0",background:theme.bg}}>
        <div className="page-wrap" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",display:"grid",gridTemplateColumns:"0.92fr 1.08fr",gap:28,alignItems:"start"}}>
          <div>
            <div style={{fontSize:12,fontWeight:800,letterSpacing:".2em",textTransform:"uppercase",color:theme.accent}}>Industries & Applications</div>
            <h2 style={{fontSize:"clamp(30px,4vw,48px)",lineHeight:1.05,letterSpacing:"-0.04em",marginTop:12,marginBottom:0}}>
              A pharma-market presentation with a broader specialty chemicals context.
            </h2>
            <p style={{color:theme.muted,lineHeight:1.9,marginTop:16}}>
              {data.productsIntro}
            </p>
          </div>
          <div style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:30,padding:28,boxShadow:"0 12px 28px rgba(31,41,55,0.05)",display:"grid",gap:14}}>
            {data.industries.map((item)=>(
              <div key={item} style={{display:"flex",alignItems:"center",gap:12,fontWeight:700}}>
                <Building2 size={18} color={theme.accent} /> {item}
              </div>
            ))}
            <div style={{height:1,background:theme.border,margin:"6px 0"}} />
            {data.products.map((item)=>(
              <div key={item} style={{display:"flex",alignItems:"center",gap:12,fontWeight:700}}>
                <FlaskConical size={18} color={theme.accent} /> {item}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="leadership" style={{padding:"88px 0",background:theme.wash}}>
        <div className="page-wrap" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto"}}>
          <SectionTitle eyebrow="Leadership" title="Leadership connected to continuity, growth, and accountability." color={theme.accent} />
          <div className="leaders-grid" style={{display:"grid",gridTemplateColumns:`repeat(${data.leaders.length},1fr)`,gap:18,marginTop:36}}>
            {data.leaders.map(([name,role])=>(
              <motion.div key={name} whileHover={{y:-4}} style={{background:"#fff",border:`1px solid ${theme.border}`,borderRadius:24,padding:24,boxShadow:"0 12px 28px rgba(31,41,55,0.05)"}}>
                <div style={{fontSize:22,fontWeight:700}}>{name}</div>
                <div style={{color:theme.muted,marginTop:8,fontSize:14}}>{role}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" style={{padding:"88px 0",background:theme.deep,color:"white"}}>
        <div className="page-wrap contact-grid" style={{width:"min(1240px, calc(100% - 48px))",margin:"0 auto",display:"grid",gridTemplateColumns:"1.08fr 0.92fr",gap:28}}>
          <div>
            <div style={{fontSize:12,fontWeight:800,letterSpacing:".2em",textTransform:"uppercase",color:"rgba(255,255,255,0.75)"}}>Contact</div>
            <h2 style={{fontSize:"clamp(30px,4vw,48px)",lineHeight:1.05,letterSpacing:"-0.04em",marginTop:12,marginBottom:0}}>
              Built to support strong customer relationships and clear communication.
            </h2>
            <div style={{display:"flex",gap:18,marginTop:24,flexWrap:"wrap"}}>
              <div style={{display:"inline-flex",alignItems:"center",gap:8,fontWeight:700}}><Users size={16}/> Relationship Focused</div>
              <div style={{display:"inline-flex",alignItems:"center",gap:8,fontWeight:700}}><Truck size={16}/> On-Time Supply</div>
              <div style={{display:"inline-flex",alignItems:"center",gap:8,fontWeight:700}}><BadgeCheck size={16}/> Quality Mindset</div>
            </div>
          </div>
          <div style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.10)",borderRadius:24,padding:26,display:"grid",gap:14}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}><Mail size={16} /> {data.contact.email}</div>
            <div style={{display:"flex",alignItems:"center",gap:10}}><Phone size={16} /> {data.contact.phone}</div>
            <div style={{display:"flex",alignItems:"center",gap:10}}><MapPin size={16} /> {data.contact.address}</div>
          </div>
        </div>
      </section>
    </main>
  );
}

function LandingCard({ type, onClick }) {
  const isVlsl = type === "vlsl";
  const logo = isVlsl ? "/logos/vlsl-logo.png" : "/logos/lido-logo.png";
  const desc = isVlsl
    ? "Pharmaceutical intermediates, specialty chemicals, solvents"
    : "Trust-led sourcing, transparency, quality, on-time delivery";
  const accent = isVlsl ? "#F97316" : "#4F5D43";

  return (
    <motion.button
      whileHover={{ y: -8, scale: 1.01 }}
      whileTap={{ scale: 0.995 }}
      onClick={onClick}
      style={{
        background: "#fff",
        border: `1px solid ${neutral.border}`,
        borderRadius: 32,
        padding: 34,
        textAlign: "left",
        boxShadow: "0 24px 70px rgba(31,41,55,0.10)",
        cursor: "pointer",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{position:"absolute",inset:0,background:isVlsl?"radial-gradient(circle at top right, rgba(249,115,22,.08), transparent 28%)":"radial-gradient(circle at top right, rgba(79,93,67,.08), transparent 28%)"}} />
      <div style={{position:"relative"}}>
        <div style={{display:"flex",justifyContent:"center",alignItems:"center",minHeight:270,overflow:"hidden"}}>
          <img src={logo} alt="" style={{maxHeight:265,width:"100%",objectFit:"contain"}} />
        </div>
        <div style={{marginTop:6,color:neutral.muted,lineHeight:1.8,fontSize:15}}>{desc}</div>
        <div style={{marginTop:18,display:"inline-flex",alignItems:"center",gap:8,color:accent,fontWeight:800,fontSize:18}}>
          Enter {isVlsl ? "VLSL" : "Lido Chem"} <ArrowRight size={18} />
        </div>
      </div>
    </motion.button>
  );
}

export default function Page() {
  const [selected, setSelected] = useState(null);

  if (selected) return <CompanyView company={selected} onHome={() => setSelected(null)} />;

  return (
    <main style={{ minHeight: "100vh", background: neutral.bg, color: neutral.text }}>
      <section style={{minHeight:"100vh",background:`linear-gradient(135deg, ${neutral.hero1} 0%, ${neutral.hero2} 100%)`,position:"relative",overflow:"hidden",display:"flex",alignItems:"center"}}>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at top left, rgba(255,255,255,0.28), transparent 24%), radial-gradient(circle at right, rgba(255,255,255,0.18), transparent 30%)"}} />
        <div className="page-wrap" style={{width:"min(1280px, calc(100% - 48px))",margin:"0 auto",position:"relative",padding:"80px 0"}}>
          <motion.div initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} transition={{duration:0.6}} style={{textAlign:"center",maxWidth:980,margin:"0 auto"}}>
            <div style={{display:"inline-flex",alignItems:"center",gap:10,background:neutral.pill,border:`1px solid ${neutral.border}`,color:neutral.accent,borderRadius:999,padding:"10px 16px",fontSize:14,fontWeight:700,boxShadow:"0 8px 20px rgba(31,41,55,0.05)"}}>
              Specialty Chemicals & Distribution
            </div>
            <h1 style={{color:neutral.text,fontSize:"clamp(42px, 6vw, 84px)",lineHeight:0.94,letterSpacing:"-0.05em",margin:"22px 0 0"}}>
              Built for trust, quality, and long-term partnerships.
            </h1>
            <p style={{color:neutral.muted,fontSize:18,lineHeight:1.9,maxWidth:860,margin:"24px auto 0"}}>
              Explore Vipul Life Science Limited and Lido Chem LLP through a market-appropriate, pharma-facing presentation focused on capability, reliability, and customer relationships.
            </p>
          </motion.div>

          <div className="landing-grid" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:26,marginTop:54}}>
            <LandingCard type="vlsl" onClick={() => setSelected("vlsl")} />
            <LandingCard type="lido" onClick={() => setSelected("lido")} />
          </div>
        </div>
      </section>
    </main>
  );
}