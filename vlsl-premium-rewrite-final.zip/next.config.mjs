export default { output: 'standalone' };
