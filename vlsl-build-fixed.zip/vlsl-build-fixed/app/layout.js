export const metadata = {
  title: "Vipul Life Science Limited | Lido Chem LLP",
  description: "Two companies. One standard of excellence.",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}